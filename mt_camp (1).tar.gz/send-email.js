import EmailRepository from "./src/repositories/email-repository.js";
import UserRepository from "./src/repositories/user-repository.js";

const emailRepo = new EmailRepository();
const userRepo = new UserRepository();

const processSendEmail = async () => {
    try {
        // Fetch the list of emails
        const emailList = await userRepo.getAllUserEmails();

        if (!emailList || emailList.length === 0) {
            console.log("No email addresses found.");
            return;
        }

        console.log(`Found ${emailList.length} email addresses. Starting the email sending process...`);

        const batchSize = 100; // Number of emails to send in one batch (reduce batch size)
        const delayBetweenEmails = 10000; // Delay in milliseconds (10 seconds) between each email
        const delayBetweenBatches = 50000; // Delay in milliseconds (50 seconds) between batches

        for (let i = 0; i < emailList.length; i += batchSize) {
            const batch = emailList.slice(i, i + batchSize);

            // Send emails in the current batch sequentially
            for (let email of batch) {
                try {
                    await emailRepo.sendWelcomeBackEmail(email);
                    console.log(`Sent email to ${email}`);
                    await new Promise((resolve) => setTimeout(resolve, delayBetweenEmails)); // Delay between each email
                } catch (emailError) {
                    console.error(`Error sending email to ${email}:`, emailError);
                }
            }

            console.log(`Batch ${i / batchSize + 1} sent successfully.`);

            // Delay before sending the next batch
            if (i + batchSize < emailList.length) {
                console.log(`Waiting for ${delayBetweenBatches / 1000} seconds before sending the next batch...`);
                await new Promise((resolve) => setTimeout(resolve, delayBetweenBatches)); // Longer delay between batches
            }
        }

        console.log("All emails have been sent.");
    } catch (error) {
        console.error("Error in the email sending process:", error);
    }
};

processSendEmail();
