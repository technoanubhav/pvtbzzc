import User from "../models/user.js";

export default class AuthRepository {
  async login(data) {
    const user = await User.findOne({
      where: {
        phone: data.phone,
        password: data.password,
      },
    });

    if (user) {
      return user.dataValues;
    } else {
      return null;
    }
  }
  async saveToken(userId, fcm_token) {
    const user = await User.findByPk(userId);

    if (user) {
      user.fcm_token = fcm_token;
      await user.save();
      return user.dataValues;
    } else {
      return null; // Handle the case where the user is not found
    }
  }

  async saveDeviceId(userId, device_id) {
    const user = await User.findByPk(userId);
    if (user) {
      user.device_id = device_id;
      await user.save();
      return user.dataValues;
    } else {
      return null; // Handle the case where the user is not found
    }
  }

  async isPhoneExists(phone) {
    const user = await User.findOne({
      where: {
        phone: phone,
      },
    });

    if (user) {
      return user.dataValues;
    } else {
      return null;
    }
  }

  async isEmailExists(email) {
    const user = await User.findOne({
      where: {
        email: email,
      },
    });

    if (user) {
      return user.dataValues;
    } else {
      return null;
    }
  }

  async isReferExists(refer) {
    const user = await User.findOne({
      where: {
        refer_code: refer,
      },
    });

    if (user) {
      return user.dataValues;
    } else {
      return null;
    }
  }

  async isDeviceExists(device_id) {
    const user = await User.findOne({
      where: {
        device_id: device_id,
      },
    });

    if (user) {
      return user.dataValues;
    } else {
      return null;
    }
  }
}
