import dayjs from "dayjs"
import transporter from "../config/mail.js"
import utc from 'dayjs/plugin/utc.js';
import timezone from 'dayjs/plugin/timezone.js';

// Load plugins
dayjs.extend(utc);
dayjs.extend(timezone);

export default class EmailRepository {
  async sendForgotPassword(user) {
    try {
      const mailOptions = {
        from: process.env.MAIL_USERNAME,
        to: user.email,
        subject: 'Forgot Password?',
        html: `
<!DOCTYPE html>
<html>
<head>
  <title>Forgot Password</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }
    .email-container {
      max-width: 600px;
      margin: 0 auto;
      background-color: #ffffff;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .header {
      background-color: #9759C4;
      color: #ffffff;
      text-align: center;
      padding: 20px 10px;
      border-radius: 8px 8px 0 0;
    }
    .header h1 {
      margin: 0;
      font-size: 24px;
    }
    .content {
      padding: 20px;
      color: #333333;
      line-height: 1.6;
    }
    .content h2 {
      color: #9759C4;
    }
    .password-box {
      display: block;
      margin: 20px 0;
      padding: 15px;
      background-color: #f2e9f9;
      color: #333333;
      border: 1px dashed #9759C4;
      text-align: center;
      font-weight: bold;
      font-size: 18px;
      border-radius: 5px;
    }
    .footer {
      text-align: center;
      color: #888888;
      font-size: 12px;
      margin-top: 20px;
    }
    .button {
      display: inline-block;
      padding: 10px 20px;
      color: #ffffff;
      background-color: #9759C4;
      text-decoration: none;
      border-radius: 5px;
      margin-top: 10px;
    }
    @media (max-width: 600px) {
      .email-container {
        padding: 10px;
      }
      .content {
        padding: 10px;
      }
    }
  </style>
</head>
<body>
  <div class="email-container">
    <div class="header">
      <h1>Forgot Your Password?</h1>
    </div>
    <div class="content">
      <h2>Hello ${user.name},</h2>
      <p>You requested to retrieve your password. Here is your current password:</p>
      <div class="password-box">${user.password}</div>
      <p>If you did not request this, please change your password immediately for security reasons.</p>
      <p>If you have any questions, feel free to contact our support team.</p>
    </div>

    <!-- Footer -->
    <div class="footer">
      <p>&copy; 2025 BuzzCash. All rights reserved.</p>
    </div>
  </div>
</body>
</html>
`
      }
      await transporter.sendMail(mailOptions)
    } catch (error) {
      throw new Error(error)
    }
  }

  async sendOfferCompleted(user, offer) {
    try {
      const mailOptions = {
        from: process.env.MAIL_USERNAME,
        to: user.email,
        subject: `${offer.name} offer completed`,
        html: `
        <!DOCTYPE html>
<html>
<head>
  <title>${offer.name} Offer Completed - Amount Credited</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }
    .email-container {
      max-width: 600px;
      margin: 0 auto;
      background-color: #ffffff;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .banner {
      width: 100%;
      display: block;
    }
    .content {
      padding: 20px;
      text-align: center;
      color: #333333;
    }
    .content h2 {
      color: #9759C4;
      font-size: 24px;
      margin-top: 20px;
    }
    .offer-logo {
      max-width: 100px;
      margin: 20px auto;
      display: block;
    }
    .amount-box {
      display: inline-block;
      margin: 20px 0;
      padding: 15px 30px;
      background-color: #f2e9f9;
      color: #333333;
      font-weight: bold;
      font-size: 20px;
      border: 2px solid #9759C4;
      border-radius: 5px;
    }
    .footer {
      text-align: center;
      color: #888888;
      font-size: 12px;
      margin-top: 20px;
      padding: 10px;
      background-color: #f9f9f9;
    }
    @media (max-width: 600px) {
      .email-container {
        margin: 10px;
      }
      .content {
        padding: 10px;
      }
    }
  </style>
</head>
<body>
  <div class="email-container">
    <!-- Banner Image -->
    <img src="${offer.banner}" alt="Offer Completed" class="banner">

    <!-- Content -->
    <div class="content">
      <h2>Congratulations!</h2>
      <p>Your offer has been successfully completed, and the amount has been credited to your account.</p>
      <div class="amount-box">₹${offer.amount}</div>
      <p>Thank you for participating in the offer. We hope to see you again!</p>
    </div>

    <!-- Footer -->
    <div class="footer">
      <p>&copy; 2025 BuzzCash. All rights reserved.</p>
    </div>
  </div>
</body>
</html>
`
      }
      await transporter.sendMail(mailOptions)
    } catch (error) {
      throw new Error(error)
    }
  }

  async sendWithdrawSuccess(user, amount) {
    try {
      const date = dayjs();

      // Convert to Indian Standard Time (IST)
      const istDate = date.tz('Asia/Kolkata');

      const mailOptions = {
        from: process.env.MAIL_USERNAME,
        to: user.email,
        subject: `Withdrawal Success ${istDate.format('YYYY-MM-DD HH:mm:ss')}`,
        html: `
       <!DOCTYPE html>
<html>
<head>
  <title>Withdrawal Success</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }
    .email-container {
      max-width: 600px;
      margin: 0 auto;
      background-color: #ffffff;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .header {
      background-color: #9759C4;
      color: #ffffff;
      text-align: center;
      padding: 20px;
    }
    .header h1 {
      margin: 0;
      font-size: 24px;
    }
    .content {
      padding: 20px;
      text-align: center;
      color: #333333;
    }
    .content h2 {
      color: #9759C4;
      margin: 10px 0;
    }
    .amount-box {
      display: inline-block;
      margin: 20px 0;
      padding: 15px 30px;
      background-color: #f2e9f9;
      color: #333333;
      font-weight: bold;
      font-size: 20px;
      border: 2px solid #9759C4;
      border-radius: 5px;
    }
    .footer {
      text-align: center;
      color: #888888;
      font-size: 12px;
      margin-top: 20px;
      padding: 10px;
      background-color: #f9f9f9;
    }
    @media (max-width: 600px) {
      .email-container {
        margin: 10px;
      }
      .content {
        padding: 10px;
      }
    }
  </style>
</head>
<body>
  <div class="email-container">
    <!-- Header -->
    <div class="header">
      <h1>Withdrawal Successful</h1>
    </div>

    <!-- Content -->
    <div class="content">
      <h2>Hi ${user.name},</h2>
      <p>We’re pleased to inform you that your withdrawal request has been successfully processed.</p>
      <div class="amount-box">Amount: ₹${amount}</div>
      <p>The amount has been credited to your account as per your request. Thank you for using our services!</p>
    </div>

    <!-- Footer -->
    <div class="footer">
      <p>&copy; 2025 BuzzCash. All rights reserved.</p>
    </div>
  </div>
</body>
</html>
`
      }
      await transporter.sendMail(mailOptions)
    } catch (error) {
      throw new Error(error)
    }
  }

  async sendWithdrawFailed(user, amount) {
    try {
      const date = dayjs();

      // Convert to Indian Standard Time (IST)
      const istDate = date.tz('Asia/Kolkata');

      const mailOptions = {
        from: process.env.MAIL_USERNAME,
        to: user.email,
        subject: `Withdrawal Failed ${istDate.format('YYYY-MM-DD HH:mm:ss')}`,
        html: `
       <!DOCTYPE html>
<html>
<head>
  <title>Withdrawal Failed</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }
    .email-container {
      max-width: 600px;
      margin: 0 auto;
      background-color: #ffffff;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .header {
      background-color: #9759C4;
      color: #ffffff;
      text-align: center;
      padding: 20px;
    }
    .header h1 {
      margin: 0;
      font-size: 24px;
    }
    .content {
      padding: 20px;
      text-align: center;
      color: #333333;
    }
    .content h2 {
      color: #9759C4;
      margin: 10px 0;
    }
    .error-box {
      display: inline-block;
      margin: 20px 0;
      padding: 15px 30px;
      background-color: #ffe6e6;
      color: #d9534f;
      font-weight: bold;
      font-size: 18px;
      border: 2px solid #d9534f;
      border-radius: 5px;
    }
    .footer {
      text-align: center;
      color: #888888;
      font-size: 12px;
      margin-top: 20px;
      padding: 10px;
      background-color: #f9f9f9;
    }
    .button {
      display: inline-block;
      padding: 10px 20px;
      color: #ffffff;
      background-color: #9759C4;
      text-decoration: none;
      border-radius: 5px;
      margin-top: 10px;
    }
    @media (max-width: 600px) {
      .email-container {
        margin: 10px;
      }
      .content {
        padding: 10px;
      }
    }
  </style>
</head>
<body>
  <div class="email-container">
    <!-- Header -->
    <div class="header">
      <h1>Withdrawal Failed</h1>
    </div>

    <!-- Content -->
    <div class="content">
      <h2>Hi ${user.name},</h2>
      <p>We regret to inform you that your withdrawal request could not be processed.</p>
      <div class="error-box">Amount: ₹${amount}</div>
      <p>Please review your withdrawal request and try again. If you need further assistance, feel free to contact our support team.</p>
    </div>

    <!-- Footer -->
    <div class="footer">
      <p>&copy; 2025 BuzzCash. All rights reserved.</p>
    </div>
  </div>
</body>
</html>

`
      }
      await transporter.sendMail(mailOptions)
    } catch (error) {
      throw new Error(error)
    }
  }

  async sendOtp(name, email, otp) {
    try {

      const mailOptions = {
        from: process.env.MAIL_USERNAME,
        to: email,
        subject: `Welcome to BuzzCash`,
        html: `<!DOCTYPE html>
<html>
<head>
  <title>Welcome to BuzzCash</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }
    .email-container {
      max-width: 600px;
      margin: 0 auto;
      background-color: #ffffff;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .header {
      background-color: #9759C4;
      color: #ffffff;
      text-align: center;
      padding: 20px;
    }
    .header h1 {
      margin: 0;
      font-size: 24px;
    }
    .content {
      padding: 20px;
      text-align: center;
      color: #333333;
    }
    .content h2 {
      color: #9759C4;
      margin: 10px 0;
    }
    .otp-box {
      display: inline-block;
      margin: 20px 0;
      padding: 15px 30px;
      background-color: #f2e9f9;
      color: #333333;
      font-weight: bold;
      font-size: 24px;
      border: 2px dashed #9759C4;
      border-radius: 5px;
    }
    .footer {
      text-align: center;
      color: #888888;
      font-size: 12px;
      margin-top: 20px;
      padding: 10px;
      background-color: #f9f9f9;
    }
    @media (max-width: 600px) {
      .email-container {
        margin: 10px;
      }
      .content {
        padding: 10px;
      }
    }
  </style>
</head>
<body>
  <div class="email-container">
    <!-- Header -->
    <div class="header">
      <h1>Welcome to BuzzCash!</h1>
    </div>

    <!-- Content -->
    <div class="content">
      <h2>Hi ${name},</h2>
      <p>Thank you for registering with us. To complete your account setup, please use the One-Time Password (OTP) below:</p>
      <div class="otp-box">${otp}</div>
      <p>The OTP is valid for the next 10 minutes. Please do not share this OTP with anyone.</p>
      <p>If you did not request this, please contact our support team immediately.</p>
    </div>

    <!-- Footer -->
    <div class="footer">
      <p>&copy; 2025 BuzzCash. All rights reserved.</p>
    </div>
  </div>
</body>
</html>
`
      }
      await transporter.sendMail(mailOptions)
      return true;
    } catch (error) {
      throw new Error(error)
    }
  }
  async sendWelcomeBackEmail(email) {
    try {

      const mailOptions = {
        from: process.env.MAIL_USERNAME,
        to: email,
        subject: "BuzzCash App is Back!",
        html: `<!DOCTYPE html>
<html>
<head>
  <title>BuzzCash App is Back!</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }
    .email-container {
      max-width: 600px;
      margin: 20px auto;
      background-color: #ffffff;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .header {
      background-color: #9759C4;
      color: #ffffff;
      text-align: center;
      padding: 30px 20px;
    }
    .header h1 {
      margin: 0;
      font-size: 28px;
    }
    .header p {
      margin: 5px 0 0;
      font-size: 16px;
    }
    .content {
      padding: 20px;
      color: #333333;
    }
    .content h2 {
      color: #9759C4;
      margin-bottom: 20px;
      text-align: center;
    }
    .features {
      text-align: left;
      margin: 20px 0;
    }
    .features ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    .features ul li {
      padding: 10px 0;
      font-size: 16px;
      line-height: 1.6;
      display: flex;
      align-items: center;
    }
    .features ul li::before {
      content: "✔";
      color: #9759C4;
      font-weight: bold;
      margin-right: 10px;
    }
    .highlight {
      background-color: #f2e9f9;
      padding: 15px;
      border-left: 5px solid #9759C4;
      margin: 20px 0;
      font-size: 15px;
    }
    .button {
      display: block;
      text-align: center;
      background-color: #9759C4;
      color: #ffffff;
      text-decoration: none;
      padding: 15px 25px;
      font-size: 16px;
      border-radius: 5px;
      margin: 30px auto;
      max-width: 200px;
    }
    .footer {
      background-color: #f9f9f9;
      color: #888888;
      text-align: center;
      padding: 15px 10px;
      font-size: 12px;
    }
    .footer a {
      color: #9759C4;
      text-decoration: none;
    }
    @media (max-width: 600px) {
      .email-container {
        margin: 10px;
      }
      .header h1 {
        font-size: 24px;
      }
      .content h2 {
        font-size: 20px;
      }
      .button {
        font-size: 14px;
      }
    }
  </style>
</head>
<body>
  <div class="email-container">
    <!-- Header -->
    <div class="header">
      <h1>The Wait is Over: BuzzCash App is Back!</h1>
      <p>Redesigned. Revamped. Reimagined.</p>
    </div>

    <!-- Content -->
    <div class="content">
      <h2>Discover What's New and Improved</h2>
      <p>We’re thrilled to announce that the BuzzCash app is back, better than ever! Packed with exciting features and improvements, it’s now easier than ever to manage your campaigns, track your earnings, and enjoy a seamless experience.</p>
      
      <div class="highlight">
        <strong>Why You'll Love the New BuzzCash App:</strong> 
        We’ve listened to your feedback and added features that make managing your campaigns and earnings smoother, faster, and more intuitive.
      </div>

      <div class="features">
        <h3>🚀 New Features at a Glance:</h3>
        <ul>
          <li>Dark Mode: Perfect for low-light environments and extended usage.</li>
          <li>Brand-New User Interface: Sleek, modern, and easy to navigate.</li>
          <li>Manage Payment Methods: Seamlessly add, edit, or delete payment methods for withdrawal.</li>
          <li>Detailed History: Access a comprehensive view of your earnings and withdrawal transactions.</li>
        </ul>
      </div>
      
      <a href="https://play.google.com/store/apps/details?id=com.codifyra.buzzcash" class="button">Download Now</a>
      
      <p>Don't miss out on the opportunity to experience the all-new BuzzCash app. Download it today and take control of your campaigns like never before!</p>
    </div>

    <!-- Footer -->
    <div class="footer">
      <p>&copy; 2025 BuzzCash. All rights reserved.</p>
    </div>
  </div>
</body>
</html>
`
      }
      await transporter.sendMail(mailOptions)
      return true;
    } catch (error) {
      throw new Error(error)
    }
  }

}