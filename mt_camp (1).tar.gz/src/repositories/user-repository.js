import Transaction from "../models/transaction.js";
import User from "../models/user.js";
import { Op, Sequelize } from "sequelize";

export default class UserRepository {
  async listReferrals(userId) {
    const user = await User.findOne({
      where: { id: userId },
    });

    const referrals = await User.findAll({
      where: { refer_by: user.dataValues.refer_code },
      order: [["createdAt", "DESC"]],
    });

    return referrals.map((refferal) => refferal.dataValues);
  }

  async getUser(userId) {
    const user = await User.findOne({
      where: { id: userId },
    });

    if (user) {
      const transactions = await Transaction.findAll({
        where: { user_id: userId },
        order: [["createdAt", "DESC"]], // Latest transactions first
      });

      const earningHistory = await Transaction.findAll({
        where: { user_id: userId, type: "credit" },
        order: [["createdAt", "DESC"]], // Latest credits first
      });

      const withdrawHistory = await Transaction.findAll({
        where: { user_id: userId, type: "debit" },
        order: [["createdAt", "DESC"]], // Latest debits first
      });

      const referrals = await User.findAll({
        where: { refer_by: user.refer_code },
        order: [["createdAt", "DESC"]],
      });

      const referRankings = await User.findAll({
        where: {
          referral_earnings: { [Op.gt]: 0 },
        },
        order: [
          [
            Sequelize.cast(Sequelize.col("referral_earnings"), "SIGNED"),
            "DESC",
          ],
        ],
        limit: 10,
        attributes: ["id", "name", "referral_earnings"],
      });

      return {
        ...user.dataValues,
        transactions: transactions.length
          ? transactions.map((transaction) => transaction.dataValues)
          : [],
        earning_history: earningHistory.length
          ? earningHistory.map((transaction) => transaction.dataValues)
          : [],
        withdraw_history: withdrawHistory.length
          ? withdrawHistory.map((transaction) => transaction.dataValues)
          : [],
        referrals: referrals.length
          ? referrals.map((refferal) => refferal.dataValues)
          : [],
        refer_rankings: referRankings.length
          ? referRankings.map((ranking) => ranking.dataValues)
          : [],
      };
    } else {
      return null;
    }
  }

  async getUserByReferCode(referCode) {
    const user = await User.findOne({
      where: {
        refer_code: referCode,
      },
    });

    if (user) {
      return user.dataValues;
    } else {
      return null;
    }
  }

  async getUserByEmail(email) {
    const user = await User.findOne({
      where: {
        email: email,
      },
    });

    if (user) {
      return user.dataValues;
    } else {
      return null;
    }
  }

  async updateBalanceByReferCode(referCode, balance) {
    const user = await User.findOne({
      where: {
        refer_code: referCode,
      },
    });

    if (user) {
      user.balance = balance;
      await user.save();
      return user.dataValues;
    } else {
      return null;
    }
  }

  async updateBalance(userId, balance) {
    const user = await User.findOne({
      where: {
        id: userId,
      },
    });

    if (user) {
      user.balance = balance;
      await user.save();
      return user.dataValues;
    } else {
      return null;
    }
  }

  async updateReferEarnings(userId, earnings) {
    const user = await User.findOne({
      where: {
        id: userId,
      },
    });

    if (user) {
      user.referral_earnings = earnings;
      await user.save();
      return user.dataValues;
    } else {
      return null;
    }
  }

  async updateUpi(userId, upi) {
    const user = await User.findOne({
      where: {
        id: userId,
      },
    });

    if (user) {
      user.upi = upi;
      await user.save();
      return user.dataValues;
    } else {
      return null;
    }
  }

  async createUser(validatedData) {
    // { name, email, password, phone, refer_code, refer_by }
    const newUser = await User.create({
      name: validatedData.name,
      email: validatedData.email,
      password: validatedData.password,
      phone: validatedData.phone,
      balance: 0,
      refer_code: validatedData.refer_code,
      refer_by: validatedData.refer,
      status: "active",
      fcm_token: validatedData.fcm_token,
      referral_earnings: "0",
      device_id: validatedData.device_id,
    });
    if (newUser) {
      return newUser.dataValues;
    } else {
      return null;
    }
  }
  async getAllUserEmails() {
    try {
      const users = await User.findAll({
        attributes: ["email"], // Select only the 'email' column
      });

      const emails = users.map((user) => user.email); // Extract emails into an array

      return emails;
    } catch (error) {
      console.error("Error fetching user emails:", error);
      throw error; // Handle or rethrow the error as needed
    }
  }

  async getUserCount(offerId) {
    const userCount = await User.count();

    return userCount; // Returns the total count of matching records
  }
}
