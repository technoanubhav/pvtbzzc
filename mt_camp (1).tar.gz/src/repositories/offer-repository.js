import OfferHistory from "../models/offer-history.js";
import Offer from "../models/offer.js";
import PostbackToken from "../models/postback-token.js";

export default class OfferRepository {
  async listOffers(type) {
    const queryOptions =
      type !== "All"
        ? { where: { type: type, status: "active" } }
        : { where: { status: "active" } };
    const offers = await Offer.findAll(queryOptions);
    if (offers) {
      return offers.map((offer) => offer.dataValues);
    }
  }

  async listOfferHistory(userId) {
    const offerHistory = await OfferHistory.findAll({
      where: { user_id: userId },
      order: [["createdAt", "DESC"]],
    });

    if (offerHistory && offerHistory.length > 0) {
      const historyWithOfferDetails = await Promise.all(
        offerHistory.map(async (history) => {
          const offer = await Offer.findOne({
            where: { id: history.offer_id },
          });
          return {
            ...history.dataValues,
            offer: offer ? offer.dataValues : null,
          };
        })
      );

      return historyWithOfferDetails;
    } else {
      return []; // Return an empty array if no history is found
    }
  }

  async getOffer(offerId) {
    const offer = await Offer.findOne({
      where: {
        id: offerId,
        status: "active",
      },
    });

    if (offer) {
      return offer.dataValues;
    } else {
      return null;
    }
  }

  async getOfferByOfferId(id, offerId) {
    const offer = await Offer.findOne({
      where: {
        id: id,
        offer_id: offerId,
        status: "active",
      },
    });

    if (offer) {
      return offer.dataValues;
    } else {
      return null;
    }
  }

  async getOfferHistory(offerId, userId) {
    const offerHistory = await OfferHistory.findOne({
      where: {
        offer_id: offerId,
        user_id: userId,
      },
    });

    if (offerHistory) {
      return offerHistory.dataValues;
    } else {
      return null;
    }
  }

  async getOfferHistoryCount(offerId) {
    const offerHistoryCount = await OfferHistory.count({
      where: {
        offer_id: offerId,
        status: "success",
      },
    });

    return offerHistoryCount; // Returns the total count of matching records
  }

  async updateOfferHistoryStatus(id, newStatus) {
    const offerHistory = await OfferHistory.findOne({
      where: {
        id: id,
      },
    });
    if (offerHistory) {
      offerHistory.status = newStatus;
      await offerHistory.save();
      return offerHistory.dataValues;
    } else {
      return null;
    }
  }

  async addOfferHistory(offer) {
    const newOffer = await OfferHistory.create({
      user_id: offer.user_id,
      offer_id: offer.offer_id,
      amount: offer.amount,
      status: offer.status,
    });
    return newOffer;
  }

  async addPostbackToken(data) {
    const newToken = await PostbackToken.create({
      user_id: data.user_id,
      offer_id: data.offer_id,
      token: data.token,
    });
    return newToken;
  }

  async getPostbackToken(offerId, token) {
    const postbackToken = await PostbackToken.findOne({
      where: {
        offer_id: offerId,
        token: token,
      },
    });

    if (postbackToken) {
      return postbackToken.dataValues;
    } else {
      return null;
    }
  }
  async deletePostbackToken(offerId, token) {
    // Find the postback token for the given user ID
    const deletedToken = await PostbackToken.destroy({
      where: {
        offer_id: offerId,
        token: token,
      },
    });

    if (deletedToken) {
      return true;
    } else {
      return false;
    }
  }
}
