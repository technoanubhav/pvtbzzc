import Setting from "../models/setting.js";

export default class SettingRepository {
  async getSettings() {
    const setting = await Setting.findOne({
      where: { id: 1 },
    });

    return setting ? setting.dataValues : null;
  }
}
