import Transaction from "../models/transaction.js";

export default class TransactionRepository {
  async addTransaction(transaction) {
    const newTransaction = await Transaction.create({
      user_id: transaction.user_id,
      image: transaction.image,
      title: transaction.title,
      type: transaction.type,
      amount: transaction.amount,
      bonus_type: transaction.bonus_type,
      status: transaction.status,
    });
    if (newTransaction) {
      return newTransaction.dataValues;
    } else {
      return null;
    }
  }

  async listTransactions(userId) {
    const transactions = await Transaction.findAll({ where: { user_id: userId } });
    if (transactions) {
      return transactions.dataValues;
    } else {
      return null;
    }
  }
}
