import Banner from "../models/banner.js";

export default class BannerRepository {
  async listBanners() {
    const banners = await Banner.findAll();
    
    if (banners) {
      const bannersFormated= banners.map((banner) => banner.dataValues);
      return bannersFormated;
    } else {
      return null;
    }
  }
}
