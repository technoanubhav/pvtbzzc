import Category from "../models/category.js";

export default class CategoryRepository {
  async listCategories() {
    const categories = await Category.findAll();
    if (categories) {
      return categories.map((category) => category.dataValues);
    }
  }
}
