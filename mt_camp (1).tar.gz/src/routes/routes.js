import express from "express";
import OfferController from "../controllers/offer-controller.js";
import CategoryController from "../controllers/category-controller.js";
import AuthController from "../controllers/auth-controller.js";
import { authenticateUser } from "../utils/authenticate-user.js";
import UserController from "../controllers/user-controller.js";
import BannerController from "../controllers/banner-controller.js";
import SettingController from "../controllers/setting-controller.js";

const offerRouter = express.Router();
const categoryRouter = express.Router();
const authRouter = express.Router();
const userRouter = express.Router();
const bannerRouter = express.Router();
const settingRouter = express.Router();

const offer = new OfferController();
const category = new CategoryController();
const auth = new AuthController();
const user = new UserController();
const banner = new BannerController();
const setting = new SettingController();

//Auth
authRouter.route("/login").post(auth.login);
authRouter.route("/send-otp").post(auth.sendOtp);
authRouter.route("/verify-otp").post(auth.verifyOtp);
authRouter.route("/forgot-password").post(auth.forgotPassword);

//User
userRouter.route("/get").post(authenticateUser, user.getUser);
userRouter.route("/update-upi").post(authenticateUser, user.updateUpi);
userRouter.route("/list-referrals").post(authenticateUser, user.listReferrals);
userRouter.route("/withdraw").post(authenticateUser, user.withdraw);
userRouter.route("/process-withdraw").post(user.processWithdraw);

//Offers
offerRouter.route("/list").post(authenticateUser, offer.listOffers);
offerRouter
  .route("/list-by-category")
  .post(authenticateUser, offer.listOffersByCategory);
offerRouter
  .route("/list-history")
  .post(authenticateUser, offer.listOfferHistory);
offerRouter.route("/claim").post(authenticateUser, offer.claimOffer);
offerRouter.route("/fire").post(offer.firePostback);

//category
categoryRouter.route("/list").post(authenticateUser, category.listCategories);

//Banner
bannerRouter.route("/list").post(authenticateUser, banner.listBanners);

//Settings
settingRouter.route("/list").post(setting.getSettings);

const configureRoutes = (app) => {
  app.use("/api/offer", offerRouter);
  app.use("/api/category", categoryRouter);
  app.use("/api/auth", authRouter);
  app.use("/api/user", userRouter);
  app.use("/api/banner", bannerRouter);
  app.use("/api/settings", settingRouter);
};

export default configureRoutes;
