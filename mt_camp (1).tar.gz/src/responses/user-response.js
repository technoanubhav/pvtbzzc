export default class UserResponse {
  static async format(user) {
    return {
      id: user.id,
      name: user?.name,
      email: user?.email,
      phone: user?.phone,
      balance: user?.balance,
      refer_code: user?.refer_code,
      country: user?.country,
      refer_by: user?.refer_by,
      status: user?.status,
      upi: user?.upi,
      referral_earnings: user?.referral_earnings,
      transactions: user?.transactions
        ? user?.transactions.map((transaction) => {
            return {
              id: transaction.id,
              image: transaction.image,
              amount: transaction.amount,
              title: transaction.title,
              type: transaction.type,
              bonus_type: transaction.bonus_type,
              status: transaction.status,
              createdAt: transaction.createdAt,
              updatedAt: transaction.updatedAt,
            };
          })
        : null,
      withdraw_history: user?.withdraw_history
        ? user?.withdraw_history.map((transaction) => {
            return {
              id: transaction.id,
              image: transaction.image,
              amount: transaction.amount,
              title: transaction.title,
              type: transaction.type,
              bonus_type: transaction.bonus_type,
              status: transaction.status,
              createdAt: transaction.createdAt,
              updatedAt: transaction.updatedAt,
            };
          })
        : null,
      earning_history: user?.earning_history
        ? user?.earning_history.map((transaction) => {
            return {
              id: transaction.id,
              image: transaction.image,
              amount: transaction.amount,
              title: transaction.title,
              type: transaction.type,
              bonus_type: transaction.bonus_type,
              status: transaction.status,
              createdAt: transaction.createdAt,
              updatedAt: transaction.updatedAt,
            };
          })
        : null,
      referrals: user?.referrals
        ? user?.referrals.map((refferal) => {
            return {
              id: refferal.id,
              name: refferal?.name,
            };
          })
        : null,
      refer_rankings: user?.refer_rankings
        ? user?.refer_rankings.map((ranking) => {
            return {
              id: ranking.id,
              name: ranking?.name,
              referral_earnings: ranking?.referral_earnings,
            };
          })
        : null,
    };
  }
}
