export default class ReferralResponse {
    static async format(referral) {
        return {
            id: referral.id,
            name: referral?.name,
        }
    }
}