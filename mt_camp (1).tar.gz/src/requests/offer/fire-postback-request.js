import Joi from "joi";
import { CustomValidationError } from "../../exceptions/custom-validation-error.js";
import joiCustomMessages from "../../utils/joi-custom-messages.js";
import cleanErrorMessage from "../../utils/clean-error-message.js";
import OfferRepository from "../../repositories/offer-repository.js";

const offerRepo = new OfferRepository()

// Defining custom options for Joi validation, including custom error messages
const options = {
  messages: joiCustomMessages,
};
export default class FirePostbackRequest {
  /**
   * Add validation rules for the request
   */
  static schema = Joi.object({
    token: Joi.string().required(),
    camp_id: Joi.number().required(),
    offer_id: Joi.number().required()
  }).options(options);

  constructor(req) {
    this.data = req.body
  }

  async validate() {
    const { error, value } = FirePostbackRequest.schema.validate(this.data, {
      abortEarly: false,
    });
    const checkToken = await offerRepo.getPostbackToken(this.data.camp_id, this.data.token)
    const checkOffer = await offerRepo.getOfferByOfferId(this.data.camp_id, this.data.offer_id)



    if (error || checkToken == null || checkOffer == null) {
      // Aggregate validation errors into an object where each key corresponds to the field name and the value is the error message.
      const validationErrors =
        // Use optional chaining to safely access error details if they exist.
        error?.details.reduce((acc, err) => {
          // For each error, add a key-value pair to the accumulator object.
          // The key is the field name (err.context.key), and the value is the error message (err.message).
          acc[err.context.key] = cleanErrorMessage(err.message);
          return acc; // Return the updated accumulator for the next iteration.
        }, {}) || // Initialize the accumulator as an empty object.
        {}; // If there are no error details, default to an empty object.
      if (checkToken == null || checkOffer == null) {
        validationErrors['token'] = 'Unauthenticated'
      }
      throw new CustomValidationError(validationErrors);
    }
    return value;
  }
}
