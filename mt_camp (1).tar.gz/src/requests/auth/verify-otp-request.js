import Joi from "joi";
import { CustomValidationError } from "../../exceptions/custom-validation-error.js";
import joiCustomMessages from "../../utils/joi-custom-messages.js";
import cleanErrorMessage from "../../utils/clean-error-message.js";
import AuthRepository from "../../repositories/auth-repository.js";

// Defining custom options for Joi validation, including custom error messages
const options = {
  messages: joiCustomMessages,
};
const authRepo = new AuthRepository();
export default class VerifyOtpRequest {
  /**
   * Add validation rules for the request
   */
  static schema = Joi.object({
    name: Joi.string().min(4).required(),
    phone: Joi.string().min(10).max(10).required(),
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required(),
    refer: Joi.string().allow(""),
    fcm_token: Joi.string().allow("").required(),
    otp: Joi.number().min(6).required(),
    device_id: Joi.string().required().messages({
      "any.required": "Please update the app.",
      "string.empty": "Please update the app.",
    }),
  }).options(options);

  constructor(req) {
    this.data = req.body;
  }

  async validate() {
    const { error, value } = VerifyOtpRequest.schema.validate(this.data, {
      abortEarly: false,
    });

    let isPhoneExists = null;
    try {
      isPhoneExists = await authRepo.isPhoneExists(this.data.phone);
    } catch {
      isPhoneExists = null;
    }

    let isEmailExists = null;
    try {
      isEmailExists = await authRepo.isEmailExists(this.data.email);
    } catch {
      isEmailExists = null;
    }

    let isReferExists = null;
    try {
      if (this.data.refer) {
        isReferExists = await authRepo.isReferExists(this.data.refer);
      }
    } catch {
      isReferExists = null;
    }

    if (
      error ||
      isEmailExists != null ||
      isPhoneExists != null ||
      (this.data.refer && isReferExists == null)
    ) {
      // Aggregate validation errors into an object where each key corresponds to the field name and the value is the error message.
      const validationErrors =
        // Use optional chaining to safely access error details if they exist.
        error?.details.reduce((acc, err) => {
          // For each error, add a key-value pair to the accumulator object.
          // The key is the field name (err.context.key), and the value is the error message (err.message).
          acc[err.context.key] = cleanErrorMessage(err.message);
          return acc; // Return the updated accumulator for the next iteration.
        }, {}) || // Initialize the accumulator as an empty object.
        {}; // If there are no error details, default to an empty object.

      if (isEmailExists != null) {
        validationErrors["email"] = "Email is already registered with us";
      }
      if (isPhoneExists != null) {
        validationErrors["phone"] = "Phone is already registered with us";
      }
      if (this.data.refer && isReferExists == null) {
        validationErrors["refer"] = "Invalid refer code";
      }
      throw new CustomValidationError(validationErrors);
    }
    return value;
  }
}
