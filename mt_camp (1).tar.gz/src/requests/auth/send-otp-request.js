import axios from "axios";
import Joi from "joi";
import { CustomValidationError } from "../../exceptions/custom-validation-error.js";
import joiCustomMessages from "../../utils/joi-custom-messages.js";
import cleanErrorMessage from "../../utils/clean-error-message.js";
import AuthRepository from "../../repositories/auth-repository.js";

// Defining custom options for Joi validation, including custom error messages
const options = {
  messages: joiCustomMessages,
};
const authRepo = new AuthRepository();

export default class SendOtpRequest {
  /**
   * Add validation rules for the request
   */
  static schema = Joi.object({
    name: Joi.string().min(4).required(),
    phone: Joi.string().min(10).max(10).required(),
    email: Joi.string()
      .email()
      .regex(/^[a-zA-Z0-9._%+-]+@gmail\.com$/)
      .required()
      .messages({
        "string.pattern.base": "Email must be a Gmail address.",
      }),
    password: Joi.string().min(6).required(),
    device_id: Joi.string().required(),
    token: Joi.string().required(),
    refer: Joi.string().allow(""),
  }).options(options);

  constructor(req) {
    this.data = req.body;
  }

  async validate() {
    const { error, value } = SendOtpRequest.schema.validate(this.data, {
      abortEarly: false,
    });

    let isPhoneExists = null;
    try {
      isPhoneExists = await authRepo.isPhoneExists(this.data.phone);
    } catch {
      isPhoneExists = null;
    }

    let isEmailExists = null;
    try {
      isEmailExists = await authRepo.isEmailExists(this.data.email);
    } catch {
      isEmailExists = null;
    }

    let isReferExists = null;
    try {
      if (this.data.refer) {
        isReferExists = await authRepo.isReferExists(this.data.refer);
      }
    } catch {
      isReferExists = null;
    }

    let checkDevice = null;
    try {
      checkDevice = await authRepo.isDeviceExists(this.data.device_id);
    } catch {
      checkDevice = null;
    }

    // Google Token Validation
    let googleTokenValid = false;
    try {
      const token = this.data.token; // The token sent from the client

      const response = await axios.get(
        `https://oauth2.googleapis.com/tokeninfo?id_token=${token}`
      );

      const payload = response.data;

      // Ensure the token belongs to your expected client (audience check)
      if (payload.aud == process.env.GOOGLE_CLIENT_ID) {
        googleTokenValid = true; // Token is valid
      }
    } catch (error) {
      googleTokenValid = false; // Token validation failed
    }

    if (
      error ||
      isEmailExists != null ||
      isPhoneExists != null ||
      (this.data.refer && isReferExists == null) ||
      checkDevice != null ||
      !googleTokenValid // Check for Google Token validity
    ) {
      // Aggregate validation errors into an object where each key corresponds to the field name and the value is the error message.
      const validationErrors =
        // Use optional chaining to safely access error details if they exist.
        error?.details.reduce((acc, err) => {
          // For each error, add a key-value pair to the accumulator object.
          // The key is the field name (err.context.key), and the value is the error message (err.message).
          acc[err.context.key] = cleanErrorMessage(err.message);
          return acc; // Return the updated accumulator for the next iteration.
        }, {}) || // Initialize the accumulator as an empty object.
        {}; // If there are no error details, default to an empty object.

      if (isEmailExists != null) {
        validationErrors["email"] = "Email is already registered with us";
      }
      if (isPhoneExists != null) {
        validationErrors["phone"] = "Phone is already registered with us";
      }
      if (this.data.refer && isReferExists == null) {
        validationErrors["refer"] = "Invalid refer code";
      }
      if (checkDevice != null) {
        validationErrors[
          "device_id"
        ] = `This device is already registered with another account. Please login to that account. phone : ${checkDevice.phone}`;
      }
      if (!googleTokenValid) {
        validationErrors["email"] = "Unauthenticated";
      }
      throw new CustomValidationError(validationErrors);
    }
    return value;
  }
}
