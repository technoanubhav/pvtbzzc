import Joi from "joi";
import { CustomValidationError } from "../../exceptions/custom-validation-error.js";
import joiCustomMessages from "../../utils/joi-custom-messages.js";
import cleanErrorMessage from "../../utils/clean-error-message.js";

// Defining custom options for Joi validation, including custom error messages
const options = {
  messages: joiCustomMessages,
};
export default class LoginRequest {
  /**
   * Add validation rules for the request
   */
  static schema = Joi.object({
    phone: Joi.string().min(10).max(10).required(),
    password: Joi.string().min(6).required(),
    fcm_token: Joi.string().allow(""),
    device_id: Joi.string().required().messages({
      "any.required": "Please update the app.",
      "string.empty": "Please update the app.",
    }),
  }).options(options);

  constructor(req) {
    this.data = req.body;
  }

  async validate() {
    const { error, value } = LoginRequest.schema.validate(this.data, {
      abortEarly: false,
    });

    if (error) {
      // Aggregate validation errors into an object where each key corresponds to the field name and the value is the error message.
      const validationErrors =
        // Use optional chaining to safely access error details if they exist.
        error?.details.reduce((acc, err) => {
          // For each error, add a key-value pair to the accumulator object.
          // The key is the field name (err.context.key), and the value is the error message (err.message).
          acc[err.context.key] = cleanErrorMessage(err.message);
          return acc; // Return the updated accumulator for the next iteration.
        }, {}) || // Initialize the accumulator as an empty object.
        {}; // If there are no error details, default to an empty object.

      throw new CustomValidationError(validationErrors);
    }
    return value;
  }
}
