import { DataTypes } from "sequelize";
import { sequelize } from "../config/db.js";

const Offer = sequelize.define(
  "offers",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    url: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    amount: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    status: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    image: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    offer_id: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    event: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    steps: {
      type: DataTypes.TEXT(20000),
      allowNull: false,
    },
    about: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    banner: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    total_installs: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    type: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
  },
  {
    tableName: "offers",
    charset: "utf8",
    collate: "utf8_general_ci",
    engine: "MyISAM",
  }
);

export default Offer;
