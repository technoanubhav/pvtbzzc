import { DataTypes } from "sequelize";
import { sequelize } from "../config/db.js";

const PostbackToken = sequelize.define(
    "postback_tokens",
    {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },
        user_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        offer_id: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },
        token: {
            type: DataTypes.TEXT,
            allowNull: false,
        },
    },
    {
        tableName: "postback_tokens",
        charset: "utf8",
        collate: "utf8_general_ci",
        engine: "MyISAM",
    }
);

export default PostbackToken;
