import { DataTypes } from "sequelize";
import { sequelize } from "../config/db.js";

const User = sequelize.define(
  "User",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      allowNull: false,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    upi: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    password: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    phone: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    balance: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    refer_code: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    refer_by: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    status: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    fcm_token: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    device_id: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    referral_earnings: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
  },
  {
    tableName: "tb_user",
    charset: "utf8",
    collate: "utf8_general_ci",
    engine: "MyISAM",
  }
);

export default User;
