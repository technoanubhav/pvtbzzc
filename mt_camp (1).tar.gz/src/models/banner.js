import { DataTypes } from "sequelize";
import { sequelize } from "../config/db.js";

const Banner = sequelize.define(
  "banners",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    image: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    url: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
  },
  {
    tableName: "tb_banners",
    charset: "utf8",
    collate: "utf8_general_ci",
    engine: "MyISAM",
  }
);

export default Banner;
