import { DataTypes } from "sequelize";
import { sequelize } from "../config/db.js";

const Setting = sequelize.define(
  "tb_setting",
  {
    id: {
      type: DataTypes.INTEGER(255),
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    site_name: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    site_url: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    site_logo: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    per_refer: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    captcha_site_key: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    captcha_private_key: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    earning_percent: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    min_withdrawal: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    max_withdrawal: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    tg_channel: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    tg_support: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    admin_key: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    reffer_offers: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    maintenance: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    updation: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    app_url: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    amount_per_ad: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    offer_extras: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    daily_ad_count: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    isGmail: {
      type: DataTypes.INTEGER(255),
      allowNull: false,
    },
    alert: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
  },
  {
    timestamps: false,
    tableName: "tb_setting",
  }
);

export default Setting;
