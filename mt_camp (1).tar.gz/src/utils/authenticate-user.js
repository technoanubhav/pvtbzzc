import jwt from "jsonwebtoken";
import UserRepository from "../repositories/user-repository.js";

const userRepo = new UserRepository();

/**
 * @DESC Verify JWT from authorization header Middleware
 */
const authenticateUser = async (req, res, next) => {
  const authHeader = req.headers["authorization"];
  if (!authHeader) {
    res.status(401).json({ message: "Unauthorized" });
  } else {
    const token = authHeader.split(" ")[1];
    if (token) {
      const secret =
        process.env.JWT_SECRET ||
        "<<<<<++++random++++secret++++string++++>>>>>>";
      jwt.verify(token, secret, async (err, decoded) => {
        if (decoded) {
          const { userId } = decoded;
          const user = await userRepo.getUser(userId);
          if (user.status == "inactive") {
            res.status(401).json({ message: "Unauthorized" });
          } else {
            req.session.user = user;
            if (err) {
              res.status(401).json({ message: "Unauthorized" });
            }
            next();
          }
        } else {
          res.status(401).json({ message: "Unauthorized" });
        }
      });
    } else {
      res.status(401).json({ message: "Unauthorized" });
    }
  }
};

export { authenticateUser };
