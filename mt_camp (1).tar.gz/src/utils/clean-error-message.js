/**
 * Cleans and formats an error message for better readability.
 * @param {string} errorMessage - The error message to be cleaned.
 * @returns {string} The cleaned and formatted error message.
 */
const cleanErrorMessage = (errorMessage) => {
    // Remove special characters & underscores with spaces in the cleaned error message.
    const cleanedMessage = errorMessage.replace(/[",']/g, '').replaceAll('_', ' ')

    if (cleanedMessage.endsWith(' id')) {
        return cleanedMessage.slice(0, -3) + "."
    }
    return cleanedMessage + "."
}

export default cleanErrorMessage
