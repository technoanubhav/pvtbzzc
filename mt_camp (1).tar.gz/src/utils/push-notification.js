import firebaseAdmin from "firebase-admin";

export default class PushNotification {
 static async sendNotification(validatedData) {
    if (!firebaseAdmin.apps.length) {
      // Initialize Firebase Admin SDK with default service account file
      firebaseAdmin.initializeApp({
        credential: firebaseAdmin.credential.cert("src/config/serviceAccount.json"),
      });
    }

    const message = {
      notification: {
        title: validatedData.title,
        body: validatedData.body,
      },
      tokens: validatedData.fcm_tokens,
      data: validatedData.data,
    };

    const response = await firebaseAdmin.messaging().sendEachForMulticast(message);

    // Check if the notification was sent successfully
    if (response.responses[0].success) {
      return true;
    } else {
      false;
    }
  }
}
