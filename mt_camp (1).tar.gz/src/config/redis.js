import Redis from "ioredis";

const redisClient = Redis.createClient({
    host: 'localhost',
    port: 6379,
    legacyMode: true,
    db: 0,
    maxRetriesPerRequest: null,
})
export default redisClient