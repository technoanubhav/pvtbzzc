import { CustomValidationError } from "../exceptions/custom-validation-error.js";
import CategoryRepository from "../repositories/category-repository.js";

const categoryRepo = new CategoryRepository();
export default class CategoryController {
  async listCategories(req, res) {
    try {
      const categories = await categoryRepo.listCategories();

      if (categories) {
        const allCategory = { id: 0, name: "All", position: 0 };
        const data = [allCategory, ...categories];
        res.status(200).json({
          status: true,
          message: "Categories listed sucessfully",
          data: data,
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Failed to list categories",
          data: [],
        });
      }
    } catch (errors) {
      if (errors instanceof CustomValidationError) {
        res.status(422).json({
          status: false,
          message: "Failed to list categories",
          data: errors.error,
        });
      } else {
        res.status(500).json({
          status: false,
          message: "Failed to list categories",
          data: errors,
        });
      }
    }
  }
}
