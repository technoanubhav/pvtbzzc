import dayjs from "dayjs";
import { CustomValidationError } from "../exceptions/custom-validation-error.js";
import CategoryRepository from "../repositories/category-repository.js";
import EmailRepository from "../repositories/email-repository.js";
import OfferRepository from "../repositories/offer-repository.js";
import SettingRepository from "../repositories/setting-repository.js";
import TransactionRepository from "../repositories/transaction-repository.js";
import UserRepository from "../repositories/user-repository.js";
import ClaimOfferRequest from "../requests/offer/claim-offer-request.js";
import FirePostbackRequest from "../requests/offer/fire-postback-request.js";
import ListOfferRequest from "../requests/offer/list-offer-request.js";
import { generateUUID } from "../utils/generate-uuid.js";
import PushNotification from "../utils/push-notification.js";
import axios from "axios";

const offerRepo = new OfferRepository();
const categoryRepo = new CategoryRepository();
const userRepo = new UserRepository();
const settingRepo = new SettingRepository();
const transactionRepo = new TransactionRepository();
const emailRepo = new EmailRepository();
export default class OfferController {
  async listOffers(req, res) {
    try {
      const validatedData = await new ListOfferRequest(req).validate();
      const offers = await offerRepo.listOffers(validatedData.type);

      const filterOffers = await Promise.all(
        offers.map(async (offer) => {
          const offerHistory = await offerRepo.getOfferHistory(
            offer.id,
            req.session.user.id
          );
          return offerHistory?.status === "success" ? null : offer;
        })
      );

      // Remove null values from the array
      const filteredOffers = filterOffers.filter(Boolean);

      if (filteredOffers) {
        res.status(200).json({
          status: true,
          message: "Offers listed sucessfully",
          data: filteredOffers,
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Failed to list offers",
          data: [],
        });
      }
    } catch (errors) {
      if (errors instanceof CustomValidationError) {
        res.status(422).json({
          status: false,
          message: "Failed to list offers",
          data: errors.errors,
        });
      } else {
        res.status(500).json({
          status: false,
          message: "Failed to list offers",
          data: errors,
        });
      }
    }
  }

  async listOffersByCategory(req, res) {
    try {
      // Fetch categories
      const categories = await categoryRepo.listCategories();

      // Sort categories based on position, ensuring categories without position come last
      const sortedCategories = categories.sort((a, b) => {
        if (a.position === undefined && b.position === undefined) return 0;
        if (a.position === undefined) return 1;
        if (b.position === undefined) return -1;
        return a.position - b.position;
      });

      // Create an array to hold the categories and their offers
      const categoryOffers = (
        await Promise.all(
          sortedCategories.map(async (category) => {
            const offers = await offerRepo.listOffers(category.name);
            // Filter out offers based on offer history
            const filteredOffers = (
              await Promise.all(
                offers.map(async (offer) => {
                  const offerHistory = await offerRepo.getOfferHistory(
                    offer.id,
                    req.session.user.id
                  );
                  return offerHistory?.status === "success" ? null : offer;
                })
              )
            ).filter(Boolean); // Remove null values
            if (filteredOffers.length > 0) {
              return {
                category,
                offers: filteredOffers,
              };
            }
            return null; // Explicitly return null if no offers
          })
        )
      ).filter((result) => result !== null); // Filter out null values

      if (categoryOffers.length > 0) {
        res.status(200).json({
          status: true,
          message: "Offers listed successfully",
          data: categoryOffers,
        });
      } else {
        res.status(200).json({
          status: false,
          message: "No offers found",
          data: [],
        });
      }
    } catch (errors) {
      if (errors instanceof CustomValidationError) {
        res.status(422).json({
          status: false,
          message: "Failed to list offers",
          data: errors.errors,
        });
      } else {
        res.status(500).json({
          status: false,
          message: "Failed to list offers",
          data: errors,
        });
      }
    }
  }

  async listOfferHistory(req, res) {
    try {
      const offerHistory = await offerRepo.listOfferHistory(
        req.session.user.id
      );

      if (offerHistory) {
        res.status(200).json({
          status: true,
          message: "Offer History listed sucessfully",
          data: offerHistory,
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Failed to list offer history",
          data: [],
        });
      }
    } catch (errors) {
      res.status(500).json({
        status: false,
        message: "Failed to list offer history",
        data: errors,
      });
    }
  }

  async claimOffer(req, res) {
    try {
      const validatedData = await new ClaimOfferRequest(req).validate();

      const offer = await offerRepo.getOffer(validatedData.offer_id);
      const user = await userRepo.getUser(req.session.user.id);

      if (offer) {
        const offerHistory = await offerRepo.getOfferHistory(
          offer.id,
          req.session.user.id
        );
        if (offerHistory) {
          // offerhistory status
          if (offerHistory.status == "pending") {
            // create token
            const token = generateUUID();
            await offerRepo.addPostbackToken({
              user_id: req.session.user.id,
              offer_id: offer.id,
              token: token,
            });
            //send notification
            await PushNotification.sendNotification({
              title: offer.name,
              body: "Offer tracking started 😍",
              data: {
                image: offer.banner,
              },
              fcm_tokens: [user.fcm_token],
            });

            res.status(200).json({
              status: true,
              message: "Offer tracking started",
              token: token,
            });
          } else {
            res.status(200).json({
              status: false,
              message: "You Have Already completed This Offer",
              data: [],
            });
          }
        } else {
          // add offer history
          const addHistory = await offerRepo.addOfferHistory({
            user_id: req.session.user.id,
            offer_id: offer.id,
            amount: offer.amount,
            status: "pending",
          });
          if (addHistory) {
            // create token
            const token = generateUUID();
            await offerRepo.addPostbackToken({
              user_id: req.session.user.id,
              offer_id: offer.id,
              token: token,
            });
            res.status(200).json({
              status: true,
              message: "Offer tracking started",
              token,
            });
          } else {
            res.status(200).json({
              status: false,
              message: "Failed to claim offer",
              data: [],
            });
          }
        }
      } else {
        res.status(200).json({
          status: false,
          message: "Invalid offer",
          data: [],
        });
      }
    } catch (errors) {
      if (errors instanceof CustomValidationError) {
        res.status(422).json({
          status: false,
          message: "Failed to claim offer",
          error: errors.errors,
        });
      } else {
        res.status(500).json({
          status: false,
          message: "Failed to claim offer",
          error: errors,
        });
      }
    }
  }

  /**
   * Fire postback
   * @param {*} req
   * @param {*} res
   */
  async firePostback(req, res) {
    try {
      const validatedData = await new FirePostbackRequest(req).validate();
      const postbackToken = await offerRepo.getPostbackToken(
        validatedData.camp_id,
        validatedData.token
      );
      const user = await userRepo.getUser(postbackToken.user_id);
      const offer = await offerRepo.getOffer(postbackToken.offer_id);
      const offerHistory = await offerRepo.getOfferHistory(offer.id, user.id);

      if (offerHistory.status == "pending") {
        const settings = await settingRepo.getSettings();

        // update offer history
        const updateOfferHistory = await offerRepo.updateOfferHistoryStatus(
          offerHistory.id,
          "success"
        );
        if (updateOfferHistory) {
          //update user balance
          let userBalance = parseFloat(user.balance);
          userBalance = userBalance + parseFloat(offer.amount);
          const updateUserBalance = await userRepo.updateBalance(
            user.id,
            userBalance
          );
          if (updateUserBalance) {
            await transactionRepo.addTransaction({
              user_id: user.id,
              image: offer.image,
              title: offer.name,
              type: "credit",
              amount: offer.amount,
              bonus_type: "offer",
            });
            // send notification
            await PushNotification.sendNotification({
              title: `${offer.name} Offer completed`,
              body: `₹${offer.amount} has been credited`,
              fcm_tokens: [user.fcm_token],
            });

            // send email
            await emailRepo.sendOfferCompleted(user, offer);
          }

          // if refered by found
          if (user.refer_by && user.refer_by != "") {
            // update friend balance
            const perRefer = parseFloat(settings.per_refer);
            const referAmount = (parseFloat(offer.amount) * perRefer) / 100;

            const friend = await userRepo.getUserByReferCode(user.refer_by);
            const friendBalance = parseFloat(friend.balance) + referAmount;

            const friendReferEarnings =
              parseFloat(friend.referral_earnings) + referAmount;

            const updateFriendBalance = await userRepo.updateBalance(
              friend.id,
              friendBalance.toFixed(2)
            );
            if (updateFriendBalance) {
              await userRepo.updateReferEarnings(
                friend.id,
                friendReferEarnings
              );
              await transactionRepo.addTransaction({
                user_id: friend.id,
                title: "Referral Earnings",
                type: "credit",
                amount: referAmount,
                bonus_type: "refer",
              });
              // send notification
              await PushNotification.sendNotification({
                title: "Referral bonus credited",
                body: `${referAmount} credited from ${user.name}`,
                fcm_tokens: [friend.fcm_token],
              });
            }
          }
          await offerRepo.deletePostbackToken(offer.id, validatedData.token);

          // Define the bot token and chat ID
          const botToken = "Enter Bot ";
          const chatID = "Enter Chat id ";

          // Define the data to be sent
          const user_id = user.id;
          const camp_id = offer.id;
          const offer_id = validatedData.offer_id;
          const offer_name = offer.name;
          const camp_amount = offer.amount;
          const user_email = user.email;
          const user_name = user.name;
          const refer_by = user.refer_by;
          const user_phone = user.phone;
          const leadsCount = await offerRepo.getOfferHistoryCount(offer.id);
          // Construct the message
          let message = `<b>⚠️ <u>A new conversation has come!</u> ️</b>\n\n`;
          message += `<b>👤 <u>User ID:</u></b> ${user_id}\n\n`;
          message += `<b>🔆 <u>Camp ID:</u></b> ${camp_id}\n\n`;
          message += `<b>🔖 <u>Offer ID:</u></b> ${offer_id}\n\n`;
          message += `<b>💼 <u>Offer Name:</u></b> ${offer_name}\n\n`;
          message += `<b>💵 <u>Camp Amount:</u></b> ₹${camp_amount}\n\n`;
          message += `<b>📧 <u>User Email:</u></b> ${user_email}\n\n`;
          message += `<b>👤 <u>User Name:</u></b> ${user_name}\n\n`;
          message += `<b>🔗 <u>Refer Code:</u></b> ${refer_by}\n\n`;
          message += `<b>📞 <u>User Phone Number:</u></b> ${user_phone}\n\n`;
          message += `<b>📅 <u>Current Date:</u></b> ${dayjs()}\n\n`;
          message += `<b>💶 <u>Closing Balance:</u></b> ${userBalance}\n\n`;
          message += `<b>📊 <u>Total Leads:</u></b> ${leadsCount}\n\n`;

          // Encode the message for the Telegram API
          const url = `https://api.telegram.org/bot${botToken}/sendMessage`;

          // Send the message using Axios
          axios.post(url, {
            chat_id: chatID,
            text: message,
            parse_mode: "HTML",
          });

          res.status(200).json({
            status: true,
            message: "Offer Processed",
            data: [],
          });
        } else {
          res.status(200).json({
            status: false,
            message: "Unable to process",
            data: [],
          });
        }
      } else {
        res.status(200).json({
          status: false,
          message: "Already processed",
          data: [],
        });
      }
    } catch (errors) {
      if (errors instanceof CustomValidationError) {
        res.status(422).json({
          status: false,
          message: "Failed to fire",
          error: errors.errors,
        });
      } else {
        res.status(500).json({
          status: false,
          message: "Failed to fire",
          error: errors,
        });
      }
    }
  }
}
