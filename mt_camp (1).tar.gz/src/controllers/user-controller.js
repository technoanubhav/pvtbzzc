import { CustomValidationError } from "../exceptions/custom-validation-error.js";
import EmailRepository from "../repositories/email-repository.js";
import SettingRepository from "../repositories/setting-repository.js";
import TransactionRepository from "../repositories/transaction-repository.js";
import UserRepository from "../repositories/user-repository.js";
import ListReferralsRequest from "../requests/user/list-referrals-request.js";
import ProcessWithdrawRequest from "../requests/user/process-withdraw-request.js";
import UpdateUpiRequest from "../requests/user/update-upi-request.js";
import WithdrawRequest from "../requests/user/withdraw-request.js";
import ReferralResponse from "../responses/referral-response.js";
import UserResponse from "../responses/user-response.js";
import PushNotification from "../utils/push-notification.js";

const userRepo = new UserRepository();
const settingsRepo = new SettingRepository();
const transactionRepo = new TransactionRepository();
const emailRepo = new EmailRepository();

export default class UserController {
  async listReferrals(req, res) {
    try {
      const validatedData = await new ListReferralsRequest(req).validate();
      const referrals = await userRepo.listReferrals(req.session.user.id);
      if (referrals) {
        const data = await Promise.all(
          await referrals.map(
            async (referral) => await ReferralResponse.format(referral)
          )
        );
        res.status(200).json({
          status: true,
          message: "Friends Fetched successfully.",
          data: data,
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Failed to get Friends",
          data: [],
        });
      }
    } catch (error) {
      if (error instanceof CustomValidationError) {
        res.status(422).json({
          status: false,
          message: "Failed to list friends",
          error: error.errors,
        });
      } else {
        res.status(500).json({
          status: false,
          message: "Failed to list friends",
          error: "",
        });
      }
    }
  }
  async getUser(req, res) {
    try {
      const user = await userRepo.getUser(req.session.user.id);
      if (user) {
        const data = await UserResponse.format(user);
        res.status(200).json({
          status: true,
          message: "User Fetched successfully.",
          data: data,
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Failed to get user",
          data: [],
        });
      }
    } catch (error) {
      res.status(500).json({
        status: false,
        message: "Failed to get user",
        error: "",
      });
    }
  }

  async updateUpi(req, res) {
    try {
      const validatedData = await new UpdateUpiRequest(req).validate();
      const updateUpi = await userRepo.updateUpi(
        req.session.user.id,
        validatedData.upi
      );

      if (updateUpi) {
        res.status(200).json({
          status: true,
          message: "UPI Id updated successfully.",
          data: [],
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Failed to update upi id",
          data: [],
        });
      }
    } catch (error) {
      if (error instanceof CustomValidationError) {
        res.status(422).json({
          status: false,
          message: "Failed to update upi id",
          error: error.errors,
        });
      } else {
        res.status(500).json({
          status: false,
          message: "Failed to update upi id",
          error: "",
        });
      }
    }
  }

  async withdraw(req, res) {
    try {
      const validatedData = await new WithdrawRequest(req).validate();
      const settings = await settingsRepo.getSettings();
      if (validatedData.amount < settings.min_withdrawal) {
        res.status(200).json({
          status: false,
          message: `Minimum withdrawal amount is ${settings.min_withdrawal}`,
          data: [],
        });
      } else if (validatedData.amount > settings.max_withdrawal) {
        res.status(200).json({
          status: false,
          message: `Maximum withdrawal amount is ${settings.max_withdrawal}`,
          data: [],
        });
      } else {
        const user = await userRepo.getUser(req.session.user.id);
        if (user.upi == "" || user.upi == null) {
          res.status(200).json({
            status: false,
            message: `Please add a payment method to complete withdrawal`,
            data: [],
          });
        } else {
          if (validatedData.amount > user.balance) {
            res.status(200).json({
              status: false,
              message: `Insufficiant balance`,
              data: [],
            });
          } else {
            const newBal = user.balance - validatedData.amount;
            await userRepo.updateBalance(req.session.user.id, newBal);
            const addTransaction = await transactionRepo.addTransaction({
              user_id: req.session.user.id,
              title: "UPI Withdrawal",
              type: "debit",
              amount: validatedData.amount,
              bonus_type: "withdraw",
              status: "pending",
            });
            if (addTransaction) {
              await PushNotification.sendNotification({
                title: "Withdrawal Request Submitted 🤑",
                body: "Amount will be transfered to your account with in 24 hours",
                fcm_tokens: [user.fcm_token],
              });
              res.status(200).json({
                status: true,
                message: `Withdrawal request submitted`,
                data: [],
              });
            } else {
              res.status(200).json({
                status: false,
                message: `Withdrawal failed`,
                data: [],
              });
            }
          }
        }
      }
    } catch (error) {
      if (error instanceof CustomValidationError) {
        res.status(422).json({
          status: false,
          message: "Failed to withdraw",
          error: error.errors,
        });
      } else {
        res.status(500).json({
          status: false,
          message: "Failed to withdraw",
          error: "",
        });
      }
    }
  }

  async processWithdraw(req, res) {
    try {
      const validatedData = await new ProcessWithdrawRequest(req).validate();
      const user = await userRepo.getUser(validatedData.user_id);
      if (user) {
        if (validatedData.status == "success") {
          await PushNotification.sendNotification({
            title: "Withdrawal Success 💰",
            body: `${validatedData.amount} is credited to your account now`,
            fcm_tokens: [user.fcm_token],
          });
          await emailRepo.sendWithdrawSuccess(user, validatedData.amount);

          res.status(200).json({
            status: true,
            message: `Withdrawal success`,
            data: [],
          });
        } else if (validatedData.status == "failed") {
          await PushNotification.sendNotification({
            title: "Withdrawal Failed 🥺",
            body: "We regret to inform you that your withdrawal request could not be processed.",
            fcm_tokens: [user.fcm_token],
          });
          await emailRepo.sendWithdrawFailed(user, validatedData.amount);

          res.status(200).json({
            status: true,
            message: `Withdrawal Failed`,
            data: [],
          });
        }
      }
    } catch (error) {
      if (error instanceof CustomValidationError) {
        res.status(422).json({
          status: false,
          message: "Failed to withdraw",
          error: error.errors,
        });
      } else {
        res.status(500).json({
          status: false,
          message: "Failed to withdraw",
          error: "",
        });
      }
    }
  }
}
