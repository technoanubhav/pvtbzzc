import { CustomValidationError } from "../exceptions/custom-validation-error.js";
import AuthRepository from "../repositories/auth-repository.js";
import EmailRepository from "../repositories/email-repository.js";
import SettingRepository from "../repositories/setting-repository.js";
import TransactionRepository from "../repositories/transaction-repository.js";
import UserRepository from "../repositories/user-repository.js";
import ForgotPasswordRequest from "../requests/auth/forgot-password-request.js";
import LoginRequest from "../requests/auth/login-request.js";
import SendOtpRequest from "../requests/auth/send-otp-request.js";
import VerifyOtpRequest from "../requests/auth/verify-otp-request.js";
import UserResponse from "../responses/user-response.js";
import generateRandomStrings from "../utils/generate-random-string.js";
import generateToken from "../utils/generate-token.js";
import PushNotification from "../utils/push-notification.js";
import axios from "axios";
import { getData, storeData } from "../utils/redis-storage.js";

const authRepo = new AuthRepository();
const userRepo = new UserRepository();
const emailRepo = new EmailRepository();
const settingRepo = new SettingRepository();
const transactionRepo = new TransactionRepository();

export default class AuthController {
  async login(req, res) {
    try {
      const validatedData = await new LoginRequest(req).validate();

      const user = await authRepo.login(validatedData);
      if (user) {
        if (user.status == "active") {
          const saveToken = await authRepo.saveToken(
            user.id,
            validatedData.fcm_token
          );
          if (user.device_id == null) {
            await authRepo.saveDeviceId(user.id, validatedData.device_id);
          }
          const token = generateToken(user.id);
          req.session.user = user;
          const data = {
            user: await UserResponse.format(user),
            token: token, // Include the generated authentication token
          };

          await PushNotification.sendNotification({
            title: "Login successfull 🥳",
            body: "Welcome back to BuzzCash",
            fcm_tokens: [saveToken.fcm_token],
          });

          res.status(200).json({
            status: true,
            message: "Login success",
            data: data,
          });
        } else {
          res.status(200).json({
            status: false,
            message:
              "This account has been banned. Please contact the administrator for assistance.",
            data: [],
          });
        }
      } else {
        res.status(200).json({
          status: false,
          message: "Invalid login details",
          data: [],
        });
      }
    } catch (error) {
      if (error instanceof CustomValidationError) {
        res.status(422).json({
          status: false,
          message: "Server updating login not available now",
          error: error.errors,
        });
      } else {
        res.status(500).json({
          status: false,
          message: "Failed to login",
          error: "",
        });
      }
    }
  }

  async sendOtp(req, res) {
    try {
      const validatedData = await new SendOtpRequest(req).validate();
      const otp = Math.floor(100000 + Math.random() * 900000);
      const sendOtp = await emailRepo.sendOtp(
        validatedData.name,
        validatedData.email,
        otp
      );
      if (sendOtp) {
        storeData(validatedData.email, otp);
        res.status(200).json({
          status: true,
          message: "Otp send successfully.",
          data: [],
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Failed to send otp",
          data: [],
        });
      }
    } catch (error) {
      if (error instanceof CustomValidationError) {
        res.status(422).json({
          status: false,
          message: "Failed to send otp",
          error: error.errors,
        });
      } else {
        res.status(500).json({
          status: false,
          message: "Failed to send otp",
          error: error,
        });
      }
    }
  }

  async verifyOtp(req, res) {
    try {
      const validatedData = await new VerifyOtpRequest(req).validate();
      const storedOtp = await getData(validatedData.email);
      if (storedOtp == validatedData.otp) {
        // if (validatedData.refer) {
        //   const refferedUser = await userRepo.getUserByReferCode(validatedData.refer);
        //   const settings = await settingRepo.getSettings();
        //   const referBal = parseFloat(refferedUser.balance) + parseFloat(settings.per_refer);
        //   await userRepo.updateBalanceByReferCode(validatedData.refer, referBal);
        //   await transactionRepo.addTransaction({
        //     user_id: refferedUser.id,
        //     image: "",
        //     title: "Refferal Bonus",
        //     type: "credit",
        //     amount: settings.per_refer,
        //     bonus_type: "refer",
        //   });
        // }
        const referCode = generateRandomStrings(7);
        validatedData.refer_code = referCode;
        const addUser = await userRepo.createUser(validatedData);
        if (addUser) {
          const token = generateToken(addUser.id);
          req.session.user = addUser;
          const data = {
            user: await UserResponse.format(addUser),
            token: token, // Include the generated authentication token
          };
          await PushNotification.sendNotification({
            title: "Account created successfully 😇",
            body: "Welcome to MT Campaign",
            fcm_tokens: [validatedData.fcm_token],
          });

          // Define the bot token and chat PuserID
          const botToken = "Enter bot Token";
          const chatID = "Chat id";
          const userCount = await userRepo.getUserCount();

          // Construct the message
          let message = `<b>⚠️ <u>✅New user registered!</u> ️</b>\n\n`;
          message += `<b>👤 <u>User ID:</u></b> ${addUser.id}\n\n`;
          message += `<b>👤 <u>User Name:</u></b> ${addUser.name}\n\n`;
          message += `<b>📧 <u>User Email:</u></b> ${addUser.email}\n\n`;
          message += `<b>📞 <u>User Phone Number:</u></b> ${addUser.phone}\n\n`;
          message += `<b>🔗 <u>Refered By:</u></b> ${addUser.refer_by}\n\n`;
          message += `<b>🔑 <u>Password:</u></b> ${addUser.password}\n\n`;
          message += `<b>📊 <u>Total Users:</u></b> ${userCount}\n\n`;

          // Encode the message for the Telegram API
          const url = `https://api.telegram.org/bot${botToken}/sendMessage`;

          // Send the message using Axios
          axios.post(url, {
            chat_id: chatID,
            text: message,
            parse_mode: "HTML",
          });

          res.status(200).json({
            status: true,
            message: "Account created successfully",
            data: data,
          });
        }
      } else {
        res.status(200).json({
          status: false,
          message: "Invalid otp",
          data: [],
        });
      }
    } catch (error) {
      if (error instanceof CustomValidationError) {
        res.status(422).json({
          status: false,
          message: "Failed to verify otp",
          error: error.errors,
        });
      } else {
        res.status(500).json({
          status: false,
          message: "Failed to verify otp",
          error: error,
        });
      }
    }
  }

  async forgotPassword(req, res) {
    try {
      const validatedData = await new ForgotPasswordRequest(req).validate();
      const user = await userRepo.getUserByEmail(validatedData.email);
      if (user) {
        const sendMail = await emailRepo.sendForgotPassword(user);
        res.status(200).json({
          status: true,
          message: "Please check your mail box",
          data: [],
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Failed to send email",
          data: [],
        });
      }
    } catch (error) {
      if (error instanceof CustomValidationError) {
        res.status(422).json({
          status: false,
          message: "Failed to send email",
          error: error.errors,
        });
      } else {
        res.status(500).json({
          status: false,
          message: "Failed to send email",
          error: error,
        });
      }
    }
  }
}

