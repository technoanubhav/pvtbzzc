import BannerRepository from "../repositories/banner-repository.js";

const bannerRepo = new BannerRepository();

export default class BannerController {
  async listBanners(req, res) {
    try {
      const banners = await bannerRepo.listBanners();

      if (banners.length > 0) {
        res.status(200).json({
          status: true,
          message: "Banners listed successfully",
          data: banners,
        });
      } else {
        res.status(200).json({
          status: false,
          message: "No banners found",
          data: [],
        });
      }
    } catch (error) {
      if (error instanceof CustomValidationError) {
        res.status(422).json({
          status: false,
          message: "Validation failed",
          data: error.error,
        });
      } else {
        res.status(500).json({
          status: false,
          message: "Failed to list banners",
          data: error.message,
        });
      }
    }
  }
}
