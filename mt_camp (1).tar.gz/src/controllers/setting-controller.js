import SettingRepository from "../repositories/setting-repository.js";

const settingRepo = new SettingRepository();
export default class SettingController {
  async getSettings(req, res) {
    try {
      const settings = await settingRepo.getSettings();
      if (settings) {
        res.status(200).json({
          status: true,
          message: "Settings Fetched successfully.",
          data: settings,
        });
      } else {
        res.status(200).json({
          status: false,
          message: "Failed to get settings",
          data: [],
        });
      }
    } catch (error) {
      res.status(500).json({
        status: false,
        message: "Failed to get settings",
        error: "",
      });
    }
  }
}
