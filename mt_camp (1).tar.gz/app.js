import express from "express";
import dotenv from "dotenv";
import session from "express-session";
import bodyParser from "body-parser";
import cors from "cors";
import morgan from "morgan";
import connectDB from "./src/config/db.js";
import { requestNotFoundCheck } from "./src/middlewares/request-not-fount-check.js";
import configureRoutes from "./src/routes/routes.js";

// Load environment variables from .env file
dotenv.config();

// Create Express app
const app = express();

// Use the cors() middleware to enable CORS support
app.use(cors({
  origin: '*' // Allow all origins, adjust for production
}));

// Use Morgan for HTTP request and response logging
app.use(morgan(process.env.LOGGING_FORMAT || "dev"));

// Set view engine to 'ejs'
app.set("view engine", "ejs");

// Set view path
app.set("views", "./src/views");

// Import MongoDB connection and establish the database connection
await connectDB()
// Middleware to handle JSON data
app.use(bodyParser.json());
// Set up middleware to parse incoming JSON and urlencoded data
app.use(express.urlencoded({ extended: false }));

// Set up Express session for handling user sessions
app.use(
  session({
    resave: false, // don't save session if unmodified
    saveUninitialized: false, // don't create session until something stored
    secret: process.env.SESSION_SECRET || "mtcampaign", // secret used to sign the session ID cookie
  })
);

// Define a basic route
app.get('/', (req, res) => {
  res.send('Hello, World!');
});

// Define application routes
configureRoutes(app);

// Middleware to handle 404 Not Found errors
app.use(requestNotFoundCheck);

// Set the port and hostname for the server
const port = process.env.PORT || 3000;
const hostname = process.env.HOST || "0.0.0.0"; // Bind to all network interfaces

// Start the server and listen on the specified port and hostname
app.listen(port, hostname, () => {
  console.log(`Server is running at http://${hostname}:${port}/`);
});

export default app;
